# Waypoint — Online Course Enrollment & Completion Process

A front-end web project that simulates the full lifecycle of an online course platform: browsing a catalog, enrolling in a course, tracking module-by-module progress, and unlocking a printable certificate on completion.

Built as a college project to demonstrate the **online course enrollment and completion process** in an interactive, user-friendly way.

## Live Demo

Once deployed with GitHub Pages (see below), your site will be available at:

```
https://<your-username>.github.io/<repository-name>/
```

## Features

- **Course catalog** — searchable and filterable by level (Beginner / Intermediate), with a detail view showing the full syllabus before enrolling
- **Enrollment flow** — one-click enrollment that issues a unique learner ID and plays a stamp animation
- **Progress dashboard ("My Learning")** — a checklist per course; the progress bar and percentage update live as modules are checked off
- **Certificates** — automatically unlocks when a course reaches 100% completion, with an editable learner name and a print / save-as-PDF option
- Fully responsive layout, keyboard-accessible controls, and reduced-motion support

## Tech Stack

- HTML5, CSS3 (custom properties, grid/flexbox, no framework)
- Vanilla JavaScript (no build step, no dependencies)
- Google Fonts (Fraunces, Inter, IBM Plex Mono)

This is a static, single-page site — everything runs in the browser, so no backend or database is required to view or grade it.

## Project Structure

```
.
├── index.html      # entire application (markup, styles, and logic)
└── README.md       # this file
```

## Running Locally

No installation needed. Either:

1. Double-click `index.html` to open it directly in a browser, or
2. Serve it locally for a cleaner experience:
   ```bash
   python3 -m http.server 8000
   ```
   then visit `http://localhost:8000` in your browser.

## Deploying with GitHub Pages

1. Push this repository to GitHub (see **Uploading to GitHub** below).
2. On GitHub, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to `Deploy from a branch`.
4. Choose the `main` branch and `/ (root)` folder, then **Save**.
5. GitHub will publish the site within a minute or two at `https://<your-username>.github.io/<repository-name>/`.

## Uploading to GitHub

**Option A — GitHub web interface (no git required)**
1. Create a new repository on GitHub (don't initialize it with a README, since you already have one).
2. On the repository page, click **Add file → Upload files**.
3. Drag in `index.html` and `README.md` from this folder.
4. Commit the changes.

**Option B — Command line**
```bash
git init
git add .
git commit -m "Initial commit: Waypoint course enrollment site"
git branch -M main
git remote add origin https://github.com/<your-username>/<repository-name>.git
git push -u origin main
```

## Notes for Evaluation

- All enrollment and progress data is stored in memory for the browser session (by design, since this is a static front-end demo with no backend/database). Refreshing the page resets it.
- The course catalog, modules, and copy are sample content written for this project and can be edited directly inside `index.html`.

## License

This project was created for academic purposes.
